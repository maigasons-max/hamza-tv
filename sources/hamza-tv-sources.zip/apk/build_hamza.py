#!/usr/bin/env python3
"""Fabrique l'APK Hamza TV : application embarquee (assets) + icone sur mesure.
Usage: python3 build_hamza.py <dossier_app> <nom> <paquet>"""
import sys, os, subprocess, shutil, zipfile
from PIL import Image

BASE = os.path.dirname(os.path.abspath(__file__))
SDK = f"{BASE}/sdk/build-tools/34.0.0"
JAR = f"{BASE}/sdk/platforms/android-34/android.jar"
JAVA_HOME = f"{BASE}/jdk-17.0.12+7"
JAVA, JAVAC, KEYTOOL = f"{JAVA_HOME}/bin/java", f"{JAVA_HOME}/bin/javac", f"{JAVA_HOME}/bin/keytool"
TPL = f"{BASE}/template_hamza"

app_dir, name, pkg = sys.argv[1], sys.argv[2], sys.argv[3]
ver_code = sys.argv[4] if len(sys.argv) > 4 else "1"
ver_name = sys.argv[5] if len(sys.argv) > 5 else "1.0"
# 6e argument : adresse de l'application en ligne (sinon version embarquee seule)
url_app = sys.argv[6] if len(sys.argv) > 6 else "asset:index.html"
work = f"{BASE}/build_hamza"
shutil.rmtree(work, ignore_errors=True)
os.makedirs(f"{work}/res/values"); os.makedirs(f"{work}/java")
for d in ("mdpi","hdpi","xhdpi","xxhdpi","xxxhdpi"):
    os.makedirs(f"{work}/res/mipmap-{d}", exist_ok=True)
os.makedirs(f"{work}/assets", exist_ok=True)

ENV = dict(os.environ); ENV["JAVA_HOME"] = JAVA_HOME; ENV["PATH"] = f"{JAVA_HOME}/bin:" + ENV["PATH"]
def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, env=ENV)
    if r.returncode != 0:
        print("ERREUR:", " ".join(cmd)[:160]); print(r.stderr[-800:]); raise SystemExit(1)
    return r

# 1. manifeste + chaines
man = open(f"{TPL}/AndroidManifest.xml").read().replace("com.nexus.webapp", pkg)
man = man.replace('android:versionCode="1"', f'android:versionCode="{ver_code}"').replace('android:versionName="1.0"', f'android:versionName="{ver_name}"')
open(f"{work}/AndroidManifest.xml","w").write(man)
open(f"{work}/res/values/strings.xml","w").write(
  f'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
  f'    <string name="app_name">{name}</string>\n'
  f'    <string name="app_url">{url_app}</string>\n</resources>')
shutil.copy(f"{TPL}/res/values/styles.xml", f"{work}/res/values/styles.xml")

# 2. sources java dans le bon paquet
pkgpath = pkg.replace(".", "/")
dst = os.path.join(work, "java", pkgpath)
os.makedirs(dst, exist_ok=True)
for f in os.listdir(f"{TPL}/java/com/nexus/webapp"):
    c = open(f"{TPL}/java/com/nexus/webapp/{f}").read().replace("package com.nexus.webapp;", f"package {pkg};")
    open(os.path.join(dst, f), "w").write(c)

# 3. application embarquee
for item in os.listdir(app_dir):
    src = os.path.join(app_dir, item)
    if item in ("node_modules",): continue
    if os.path.isdir(src): shutil.copytree(src, os.path.join(work,"assets",item), dirs_exist_ok=True)
    else: shutil.copy(src, os.path.join(work,"assets",item))

# 4. icones depuis le logo
logo = os.path.join(app_dir, "assets", "icon-512.png")
if not os.path.exists(logo): logo = os.path.join(app_dir, "assets", "logo-512.png")
for d, size in (("mdpi",48),("hdpi",72),("xhdpi",96),("xxhdpi",144),("xxxhdpi",192)):
    Image.open(logo).convert("RGBA").resize((size,size), Image.LANCZOS).save(f"{work}/res/mipmap-{d}/ic_launcher.png")

# 5. ressources, bytecode, dex
os.chdir(work)
run([f"{SDK}/aapt2","compile","--dir","res","-o","res.zip"])
run([f"{SDK}/aapt2","link","-o","app.unsigned.apk","-I",JAR,"--manifest","AndroidManifest.xml",
     "--java","gen","-A","assets","--min-sdk-version","21","--target-sdk-version","34","res.zip"])
os.makedirs("classes")
rfiles=[os.path.join(dp,f) for dp,_,fs in os.walk("gen") for f in fs]
jfiles=[os.path.join(dp,f) for dp,_,fs in os.walk("java") for f in fs if f.endswith(".java")]
run([JAVAC,"-classpath",JAR,"-d","classes"]+rfiles+jfiles)
os.makedirs("dexout")
run([JAVA,"-cp",f"{SDK}/lib/d8.jar","com.android.tools.r8.D8","--release","--lib",JAR,"--output","dexout"]+
    [os.path.join(dp,f) for dp,_,fs in os.walk("classes") for f in fs if f.endswith(".class")])

# 6. dex dans l'APK
zf = zipfile.ZipFile("app.unsigned.apk","a"); zf.write("dexout/classes.dex","classes.dex"); zf.close()

# 7. alignement + signature
run([f"{SDK}/zipalign","-f","4","app.unsigned.apk","app.aligned.apk"])
ks = f"{BASE}/nexus.jks"
out = f"{BASE}/out"; os.makedirs(out, exist_ok=True)
apk = f"{out}/hamza-tv-{ver_name}.apk"
run([f"{SDK}/apksigner","sign","--ks",ks,"--ks-pass","pass:nexus2026","--ks-key-alias","nexus",
     "--out",apk,"app.aligned.apk"])
print("APK PRET:", apk, round(os.path.getsize(apk)/1e6,1), "Mo")
